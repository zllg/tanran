<?php
defined('ABSPATH') or die('You can not access this file directly.');

echo '</dev>';