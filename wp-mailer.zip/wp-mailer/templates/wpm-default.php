<?php
defined('ABSPATH') or die('You can not access this file directly.');
?>
<!DOCTYPE>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="<https://www.weipxiu.com/wp-content/themes/boke/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" media="screen and (max-width:767px)" href="https://www.weipxiu.com/wp-content/themes/boke/css/style-ios.css">
    <link rel="stylesheet" type="text/css" media="screen and (min-width:768px) and (max-width:1199px)" href="https://www.weipxiu.com/wp-content/themes/boke//css/style-ipd.css">
    <link rel="stylesheet" type="text/css" media="screen and (min-width:1200px)" href="https://www.weipxiu.com/wp-content/themes/boke//style.css">
    <title>
        <?php the_title(); ?>
    </title>
</head>

<body>
    <div class="continar">
        <div class="continar-left">
            <h2 class="title">
                <?php bloginfo('name'); ?>
            </h2>
            <h2 class="title">
                <?php the_title(); ?>
            </h2>
            <div class="log-text">
                <?php the_content(); ?>
            </div>
            <p>原文：<a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>">
                    <?php the_title(); ?></a></p>
            <p class="unsubscribe"><a href="<?php wpm_unsubscribe_url(); ?>">退订订阅</a></p>
        </div>
    </div>
</body>

</html>